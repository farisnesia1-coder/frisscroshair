package com.friss.crosshair;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.SeekBar;
import android.widget.ImageView;

public class MainActivity extends Activity {
    private int size = 92;
    private TextView status;
    private SeekBar seek;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(7,12,27));
        getWindow().setNavigationBarColor(Color.rgb(7,12,27));
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(22),dp(22),dp(22),dp(18)); root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(7,12,27),Color.rgb(14,30,58),Color.rgb(8,13,28)}));
        TextView brand=new TextView(this); brand.setText("FRISS  •  FARIS"); brand.setTextColor(Color.rgb(70,170,255)); brand.setTextSize(13); brand.setTypeface(Typeface.DEFAULT,Typeface.BOLD); brand.setGravity(Gravity.CENTER); root.addView(brand,lp(-1,-2));
        TextView title=new TextView(this); title.setText("CROSSHAIR"); title.setTextColor(Color.WHITE); title.setTextSize(29); title.setTypeface(Typeface.DEFAULT,Typeface.BOLD); title.setGravity(Gravity.CENTER); LinearLayout.LayoutParams tlp=lp(-1,-2); tlp.topMargin=dp(2); root.addView(title,tlp);
        TextView desc=new TextView(this); desc.setText("FRISS CROSSHAIR  •  MADE BY FARIS"); desc.setTextColor(Color.rgb(164,184,213)); desc.setTextSize(13); desc.setGravity(Gravity.CENTER); LinearLayout.LayoutParams dlp=lp(-1,-2); dlp.topMargin=dp(4); dlp.bottomMargin=dp(16); root.addView(desc,dlp);
        LinearLayout preview=new LinearLayout(this); preview.setGravity(Gravity.CENTER); preview.setBackground(round(Color.rgb(10,17,34),Color.rgb(35,67,108),dp(20))); LinearLayout.LayoutParams plp=lp(-1,0); plp.weight=1; plp.bottomMargin=dp(16); root.addView(preview,plp);
        ImageView logo=new ImageView(this); logo.setImageResource(com.friss.crosshair.R.drawable.crosshair_logo); logo.setScaleType(ImageView.ScaleType.FIT_CENTER); preview.addView(logo,new LinearLayout.LayoutParams(dp(210),dp(210)));
        TextView sizeLabel=new TextView(this); sizeLabel.setText("CROSSHAIR SIZE"); sizeLabel.setTextColor(Color.WHITE); sizeLabel.setTextSize(13); sizeLabel.setTypeface(Typeface.DEFAULT,Typeface.BOLD); root.addView(sizeLabel,lp(-1,-2));
        seek=new SeekBar(this); seek.setMax(130); seek.setProgress(size-30); seek.setProgressTintList(android.content.res.ColorStateList.valueOf(Color.rgb(255,40,60))); seek.setThumbTintList(android.content.res.ColorStateList.valueOf(Color.rgb(255,40,60))); root.addView(seek,lp(-1,-2));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean u){size=30+p;} public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){sendSize();}});
        status=new TextView(this); status.setText("●  OFF  •  Overlay not running"); status.setTextColor(Color.rgb(255,150,160)); status.setTextSize(13); status.setGravity(Gravity.CENTER); LinearLayout.LayoutParams st=lp(-1,-2); st.topMargin=dp(8); st.bottomMargin=dp(8); root.addView(status,st);
        Button permission=button("ALLOW DISPLAY OVER APPS",false); root.addView(permission,buttonLp()); permission.setOnClickListener(v->{if(!Settings.canDrawOverlays(this)){Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()));startActivity(i);}else status.setText("●  PERMISSION READY");});
        Button on=button("ON  •  SHOW CROSSHAIR",true); root.addView(on,buttonLp()); on.setOnClickListener(v->{if(!Settings.canDrawOverlays(this)){status.setText("Allow display over apps first");Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()));startActivity(i);return;} Intent i=new Intent(this,CrosshairService.class);i.setAction(CrosshairService.ACTION_START);i.putExtra("size",size);if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);status.setText("●  ON  •  Fixed at screen center");});
        Button off=button("OFF  •  HIDE CROSSHAIR",false); root.addView(off,buttonLp()); off.setOnClickListener(v->{stopService(new Intent(this,CrosshairService.class));status.setText("●  OFF  •  Overlay not running");});
        TextView foot=new TextView(this); foot.setText("No ads  •  No root  •  No dragging\nCrosshair stays centered on screen"); foot.setTextColor(Color.rgb(133,153,182)); foot.setTextSize(11); foot.setGravity(Gravity.CENTER); LinearLayout.LayoutParams fl=lp(-1,-2);fl.topMargin=dp(14);root.addView(foot,fl);
        setContentView(root);
    }
    private void sendSize(){if(Settings.canDrawOverlays(this)){Intent i=new Intent(this,CrosshairService.class);i.setAction(CrosshairService.ACTION_SIZE);i.putExtra("size",size);startService(i);}}
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));}
    private LinearLayout.LayoutParams buttonLp(){LinearLayout.LayoutParams p=lp(-1,52);p.topMargin=dp(8);return p;}
    private GradientDrawable round(int color,int stroke,int radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(radius);g.setStroke(dp(1),stroke);return g;}
    private Button button(String text,boolean primary){Button b=new Button(this);b.setText(text);b.setTextSize(13);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setBackground(round(primary?Color.rgb(218,25,48):Color.rgb(20,37,64),primary?Color.rgb(255,83,95):Color.rgb(49,78,116),dp(14)));return b;}
    @Override protected void onResume(){super.onResume();if(status!=null&&Settings.canDrawOverlays(this))status.setText("●  PERMISSION READY");}
}
