package com.friss.crosshair;

import android.app.Service;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;

public class CrosshairService extends Service {
 public static final String ACTION_START="start", ACTION_SIZE="size";
 private WindowManager wm; private ImageView cross; private WindowManager.LayoutParams params; private int size=92;
 @Override public void onCreate(){super.onCreate();wm=(WindowManager)getSystemService(WINDOW_SERVICE);}
 @Override public int onStartCommand(Intent intent,int flags,int startId){
  if(intent!=null&&intent.hasExtra("size"))size=intent.getIntExtra("size",92);
  if(intent!=null&&ACTION_SIZE.equals(intent.getAction())){if(cross!=null)updateCrosshair();return START_STICKY;}
  createNotification(); if(cross==null)showCrosshair();else updateCrosshair(); return START_STICKY;
 }
 private void createNotification(){String id="friss_crosshair";NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel(id,"Friss Crosshair",NotificationManager.IMPORTANCE_LOW));Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,id):new Notification.Builder(this);startForeground(101,b.setContentTitle("FRISS CROSSHAIR is ON").setContentText("Crosshair fixed at screen center. Open app and tap OFF to stop.").setSmallIcon(android.R.drawable.ic_menu_view).build());}
 private void showCrosshair(){cross=new ImageView(this);cross.setImageResource(R.drawable.crosshair_logo);cross.setScaleType(ImageView.ScaleType.FIT_CENTER);cross.setClickable(false);cross.setFocusable(false);int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;params=new WindowManager.LayoutParams(size,size,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);params.gravity=Gravity.CENTER;wm.addView(cross,params);}
 private void updateCrosshair(){if(cross==null)return;params.width=size;params.height=size;try{wm.updateViewLayout(cross,params);}catch(Exception ignored){}}
 @Override public void onDestroy(){if(cross!=null){try{wm.removeView(cross);}catch(Exception ignored){}cross=null;}stopForeground(true);super.onDestroy();}
 @Override public IBinder onBind(Intent i){return null;}
}
