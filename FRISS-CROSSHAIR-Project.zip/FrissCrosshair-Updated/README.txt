FRISS CROSSHAIR v1.1 — Android source project

Features: custom red reticle image overlay, fixed at screen center, ON/OFF controls, size slider, polished dark blue/red interface, no ads, no root, no network permission.

Build with GitHub Actions workflow in .github/workflows/build-apk.yml. This is source code, not a compiled APK. Android overlay permission is required.


LOGO UPDATE:
- App launcher icon: blue circular logo (res/mipmap-*/ic_launcher.png)
- Crosshair/preview image: transparent red reticle (res/drawable-nodpi/crosshair_logo.png)
- App branding text: FRISS • FARIS

Upload this project ZIP's contents to your GitHub repo, then run the Build FRISS Crosshair APK workflow. This is a source project, not a compiled APK.
