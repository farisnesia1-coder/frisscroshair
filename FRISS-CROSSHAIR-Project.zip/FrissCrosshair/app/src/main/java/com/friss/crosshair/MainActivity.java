package com.friss.crosshair;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.SeekBar;

public class MainActivity extends Activity {
    private int size = 34;
    private TextView status;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(28,36,28,28); root.setBackgroundColor(Color.rgb(245,248,252));
        TextView title = new TextView(this); title.setText("FRISS CROSSHAIR"); title.setTextSize(25); title.setTextColor(Color.rgb(16,35,63)); title.setGravity(Gravity.CENTER); title.setTypeface(null,1); root.addView(title, new LinearLayout.LayoutParams(-1,-2));
        TextView desc = new TextView(this); desc.setText("Crosshair plus merah • tanpa iklan • tanpa root"); desc.setTextSize(14); desc.setTextColor(Color.DKGRAY); desc.setGravity(Gravity.CENTER); LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-1,-2); dp.topMargin=12; dp.bottomMargin=26; root.addView(desc,dp);
        status = new TextView(this); status.setText("Status: belum aktif"); status.setTextSize(16); status.setTextColor(Color.DKGRAY); root.addView(status);
        TextView sizeLabel = new TextView(this); sizeLabel.setText("Ukuran crosshair"); sizeLabel.setTextSize(15); sizeLabel.setTextColor(Color.BLACK); LinearLayout.LayoutParams slp=new LinearLayout.LayoutParams(-1,-2); slp.topMargin=22; root.addView(sizeLabel,slp);
        SeekBar seek = new SeekBar(this); seek.setMax(70); seek.setProgress(size-15); root.addView(seek,new LinearLayout.LayoutParams(-1,-2));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){ public void onProgressChanged(SeekBar s,int p,boolean u){size=15+p;} public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){ if (Settings.canDrawOverlays(MainActivity.this)) { Intent i=new Intent(MainActivity.this,CrosshairService.class); i.setAction(CrosshairService.ACTION_SIZE); i.putExtra("size",size); startService(i); } }});
        Button enable = new Button(this); enable.setText("1. IZINKAN OVERLAY"); root.addView(enable,buttonParams()); enable.setOnClickListener(v->{ if(!Settings.canDrawOverlays(this)){Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())); startActivity(i);} else status.setText("Izin overlay sudah aktif."); });
        Button start = new Button(this); start.setText("2. TAMPILKAN CROSSHAIR"); root.addView(start,buttonParams()); start.setOnClickListener(v->{ if(!Settings.canDrawOverlays(this)){status.setText("Izinkan overlay dulu."); return;} Intent i=new Intent(this,CrosshairService.class); i.setAction(CrosshairService.ACTION_START); i.putExtra("size",size); if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i); status.setText("Status: crosshair aktif — bisa digeser"); });
        Button stop = new Button(this); stop.setText("MATIKAN CROSSHAIR"); root.addView(stop,buttonParams()); stop.setOnClickListener(v->{stopService(new Intent(this,CrosshairService.class)); status.setText("Status: crosshair mati");});
        TextView note = new TextView(this); note.setText("Tips: seret tanda + ke tengah layar. Jika Android meminta izin notifikasi, izinkan agar layanan tetap berjalan. Overlay mungkin tidak tampil di beberapa mode game."); note.setTextSize(13); note.setTextColor(Color.DKGRAY); LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,-2); np.topMargin=22; root.addView(note,np);
        setContentView(root);
    }
    private LinearLayout.LayoutParams buttonParams(){ LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.topMargin=10; return p; }
    @Override protected void onResume(){super.onResume(); if(status!=null && Settings.canDrawOverlays(this)) status.setText("Izin overlay tersedia");}
}
