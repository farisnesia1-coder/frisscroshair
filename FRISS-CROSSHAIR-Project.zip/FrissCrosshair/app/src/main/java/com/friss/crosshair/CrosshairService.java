package com.friss.crosshair;

import android.app.Service;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.graphics.Canvas;
import android.graphics.Paint;

public class CrosshairService extends Service {
    public static final String ACTION_START="start", ACTION_SIZE="size";
    private WindowManager wm; private CrossView cross; private WindowManager.LayoutParams params; private int size=34;
    @Override public void onCreate(){super.onCreate(); wm=(WindowManager)getSystemService(WINDOW_SERVICE);}
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent!=null && intent.hasExtra("size")) size=intent.getIntExtra("size",34);
        if(intent!=null && ACTION_SIZE.equals(intent.getAction())) { if(cross!=null){cross.setSizePx(size); cross.invalidate();} return START_STICKY; }
        createNotification(); if(cross==null) showCrosshair(); else {cross.setSizePx(size); cross.invalidate();} return START_STICKY;
    }
    private void createNotification(){
        String id="friss_crosshair"; NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel(id,"Friss Crosshair",NotificationManager.IMPORTANCE_LOW));
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,id):new Notification.Builder(this);
        startForeground(101,b.setContentTitle("Friss Crosshair aktif").setContentText("Gunakan tombol Matikan di aplikasi untuk menutup overlay.").setSmallIcon(android.R.drawable.ic_menu_view).build());
    }
    private void showCrosshair(){
        cross=new CrossView(this); int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        params=new WindowManager.LayoutParams(size*2+24,size*2+24,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,PixelFormat.TRANSLUCENT);
        params.gravity=Gravity.TOP|Gravity.START; params.x=0; params.y=getResources().getDisplayMetrics().heightPixels/2-size;
        cross.setOnTouchListener(new View.OnTouchListener(){float sx,sy; int ox,oy; public boolean onTouch(View v,MotionEvent e){switch(e.getAction()){case MotionEvent.ACTION_DOWN:sx=e.getRawX();sy=e.getRawY();ox=params.x;oy=params.y;return true;case MotionEvent.ACTION_MOVE:params.x=ox+(int)(e.getRawX()-sx);params.y=oy+(int)(e.getRawY()-sy);wm.updateViewLayout(cross,params);return true;}return true;}});
        wm.addView(cross,params);
    }
    @Override public void onDestroy(){if(cross!=null){try{wm.removeView(cross);}catch(Exception ignored){} cross=null;} stopForeground(true); super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
    private class CrossView extends View { Paint p=new Paint(3); int px; CrossView(android.content.Context c){super(c);setSizePx(size);setLayerType(View.LAYER_TYPE_SOFTWARE,null);} void setSizePx(int s){px=s;}
        @Override protected void onDraw(Canvas c){super.onDraw(c); float x=getWidth()/2f,y=getHeight()/2f; p.setColor(Color.rgb(255,20,35));p.setStrokeWidth(Math.max(1.8f,px/17f));p.setStrokeCap(Paint.Cap.SQUARE);p.setStyle(Paint.Style.STROKE); float radius=px*0.34f; float outer=px*0.52f; float gap=Math.max(2.5f,px*0.08f); c.drawCircle(x,y,radius,p); c.drawLine(x-outer,y,x-radius-gap,y,p);c.drawLine(x+radius+gap,y,x+outer,y,p);c.drawLine(x,y-outer,x,y-radius-gap,p);c.drawLine(x,y+radius+gap,x,y+outer,p); p.setStyle(Paint.Style.FILL); c.drawCircle(x,y,Math.max(1.2f,px*0.035f),p); }
    }
}
