FRISS CROSSHAIR — Android Studio project

Features:
- Red plus (+) crosshair overlay
- No ads, no root, no network permissions
- Draggable overlay and adjustable size
- Android 6+ minimum; intended for Android 15 / HyperOS

IMPORTANT:
This ZIP is Android source code, not a compiled APK. Build it with Android Studio (JDK 17 recommended) and Android SDK Platform 35 installed.
1. Extract ZIP.
2. Open the FrissCrosshair folder in Android Studio.
3. Allow Gradle sync to finish.
4. Build > Build APK(s).
5. Install the generated debug APK on your phone.

On the phone, open the app, allow "Display over other apps", tap Show Crosshair, and drag the + into position. Tap Stop in the app to remove it.

Overlay may be hidden by some games or Android modes. Use only if permitted by the game's rules. This project does not aim, read game data, or modify Free Fire.
